## Resubmission

This is a resubmission. In this version I have:

* Updated the Description to describe Rollbar and give a reference

* Updated the Title to better match the description

## Test environments

* local OS X install, R 3.3.0
* ubuntu 12.04 (on travis-ci), R 3.3.0
* win-builder

## R CMD check results

There were no ERRORs or WARNINGs.

There was 1 NOTE:

* This is a new submission

## Downstream dependencies

This is a new submission.
